package Lecture03_List_RecursionSupport

object ListExample {
  val myList: List[Int] = List()
  val listNum = List(1, 2, 3, 4, 5)
  val listStr: List[String] = List("John", "Robin", "Richard")

  def main(args: Array[String]): Unit = {
    println(myList)
    println(listNum)
    println(listStr)
  }
}
