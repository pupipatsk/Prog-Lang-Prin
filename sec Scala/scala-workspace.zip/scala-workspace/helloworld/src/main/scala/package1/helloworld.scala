package package1

object helloworld {
  def main(args: Array[String]): Unit = {
    println("helloworld!")
  }
}
