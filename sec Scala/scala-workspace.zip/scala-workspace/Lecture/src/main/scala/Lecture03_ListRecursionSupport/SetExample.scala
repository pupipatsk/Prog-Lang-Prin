package Lecture03_ListRecursionSupport

object SetExample {
  var setM: Set[Int] = Set(1,5,7,3,6)



  def main(args: Array[String]): Unit = {
    println(setM)




  }
}
