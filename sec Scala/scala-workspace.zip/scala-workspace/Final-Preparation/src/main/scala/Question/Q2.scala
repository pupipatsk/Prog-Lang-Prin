package Question

object Q2 {
  def insertInOrder(x: Int, l: List[Int]): List[Int] = {
    if (x < l.head) x :: l
    else l.head :: insertInOrder(x, l.tail)
  }

  def main(args: Array[String]): Unit = {
    println(insertInOrder(2, List(0,1,3,4)))
    println(insertInOrder(2, List(1,1,2,3,4)))
    println(insertInOrder(-1, List(-2,1,2,3,4)))
  }
}
