package Question

object Q4 {

  def reverse(list: List[Any]): List[Any] = {
    if (list.isEmpty) List()
    else reverse(list.tail) ++ List(list.head)
  }

  def palindrome(list: List[Any]):Boolean = {
    list == reverse(list)
  }

  def main(args: Array[String]): Unit = {
    println(palindrome(List()))
    println(palindrome(List(1,2,2,1)))
    println(palindrome(List(1,2,3,2,1)))
    println(palindrome(List(4,1,3,2,4)) == false)
  }
}
