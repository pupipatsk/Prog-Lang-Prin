package Question

object Q3 {

  def isNotIn(x: Any, l2: List[Any]): Boolean = {
    if (l2.isEmpty) true
    else if (x == l2.head) false
    else isNotIn(x, l2.tail)
  }

  def subList(l1: List[Any], l2: List[Any]): Boolean = {
    if (l1.isEmpty) true
    else if (l2.isEmpty) false
    else {
      if (isNotIn(l1.head, l2)) false
      else subList(l1.tail, l2)
    }
  }

  def main(args: Array[String]): Unit = {
    println(subList(List(), List()))
    println(subList(List(), List(1,2,3,4)))
    println(subList(List(1,2,3,4), List()) == false)
    println(subList(List(5), List(1,2,3,4)) == false)
    println(subList(List(1,2,3), List(1,2,3,4)))
    println(subList(List(3,2,1), List(1,2,3,4)))
    println(subList(List(1,2,3,5), List(1,2,3,4)) == false)
  }
}
