package Question

object Q1 {
  def insertAtPosition(x: Any, pos: Int, l: List[Any]): List[Any] = {
    if (pos == 0) return x :: l
    else l.head :: insertAtPosition(x, pos-1, l.tail)
  }

  def main(args: Array[String]): Unit = {
    println(insertAtPosition(2, 2, List(0,1,2,3,4)))
    println(insertAtPosition(3, 3, List(0,1,2,3,4)))
    println(insertAtPosition(3.5, 4, List(0,1,2,3,4)))
  }
}
